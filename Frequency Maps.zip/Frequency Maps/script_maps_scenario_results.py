import pandas as pd
import numpy as np

#--------------------------------------------------------------------------------------------------------------
#Create Frequency map
#--------------------------------------------------------------------------------------------------------------

#Path where initial shapefiles are located
path_shapefiles= 'C:/Users/pascu/Dropbox/Pascual/UPV PhD/6. Pasantia TUD/Swmm models dresden/Flooding Model/Shapefiles/'

#Path where results are located
path_data= 'C:/Users/pascu/Dropbox/Pascual/UPV PhD/6. Pasantia TUD/Swmm models dresden/Frequency Maps/'

#path SWMM model
path_model= 'C:/Users/pascu/Dropbox/Pascual/UPV PhD/6. Pasantia TUD/Swmm models dresden/Input Information/SUDS_Scenario/'
          
#-------------------------------------------------------------------------------------------------------------------------------------------------
#1 LOAD basic shapefiles
#-----------------------------------------------------------------------------------------------------------------------------------------------------

#load polygon representing buildings in the study area. These are derived from OSM. To see how they are extracted check README_DOWNLOAD_OSM
subcatchments = QgsVectorLayer(path_shapefiles + 'SWMM_subcatchments.shp', "subcatchments", "ogr")
QgsProject.instance().addMapLayer(subcatchments)

#-------------------------------------------------------------------------------------------------------------------------------------------------
#2 Process results from optimization
#-----------------------------------------------------------------------------------------------------------------------------------------------------
#Scenario to be chosen--> depends on Pareto Table and graph
scenario=2

#load results for all scenarios and buildings. 1= Buildings was optimal for that scenario, 0 otherwise
df_pareto_front= pd.read_csv(path_data +'MS5_pareto_front_10T_30D.csv', sep=',', header=None)
pareto_front= df_pareto_front.to_numpy()

#load results for all scenarios and subcatchments. 1= an LID was optimal for that subcatchment for that scenario, 0 otherwise
scenario_results= pd.read_csv(path_data + 'MS5_scenario_results_10T_30D.txt', sep=',', header=None)
scenario_results= scenario_results.to_numpy()

n_scenarios= np.shape(scenario_results)[0]
n_subcatchments= np.shape(scenario_results)[1]

#REad SWMM model to get name of subcatchments
name_model= path_model + 'ms5_SUDS.inp'
f= open(name_model, 'r')
                               

#read each line and storages it as a list of strings
lines= f.readlines()

#find the section for NODE FLOODING
idx_ini= lines.index('[SUBCATCHMENTS]\n')
idx_end= lines.index('[SUBAREAS]\n')

idx= lines[idx_ini+1:idx_end-1]#CAREFUL here, the +3 and -1 have been adapted for this model
subcatchment_list=[]
subcatchment_land_use_list=[]
subcatchment_suds_list=[]

for i in idx:
    a=i.split()
    subcatchment_list.append(a[0])
    
    if a[0].split('_')[0]=='Stone':
        subcatchment_suds_list.append('Permeable_Pavement')
        subcatchment_land_use_list.append('Stone_Paver')
    elif a[0].split('_')[0]=='Vegetation':
        subcatchment_suds_list.append('Rain_Garden')
        subcatchment_land_use_list.append('Vegetation')
    elif a[0].split('_')[0]=='Roof':
        subcatchment_suds_list.append('Green_Roof')
        subcatchment_land_use_list.append('Roof')
    elif a[0].split('_')[0]=='Street':
        subcatchment_suds_list.append('Permeable_Pavement')
        subcatchment_land_use_list.append('Street')
    elif a[0].split('_')[0]=='Sand':
        subcatchment_suds_list.append('Infiltration_Trenches')
        subcatchment_land_use_list.append('Sand_Gravel')
        

#Dataframe with results for specific scenario.1= Buildings was optimal for that scenario, 0 otherwise
df=pd.DataFrame(list(zip(subcatchment_list, subcatchment_land_use_list, subcatchment_suds_list)), columns =['Name', 'Land_Use', 'SUDS'])
df['Results']= scenario_results[scenario,:]
#save results as CSV file
df.to_csv(path_data +'Results_Scenario_'+str(scenario)+'.csv', sep=',', index=None)

# Add results to shapefiles
processing.run("native:joinattributestable", {'INPUT':subcatchments,'FIELD':'Name','INPUT_2':path_data+ 'Results_Scenario_'+str(scenario)+'.csv','FIELD_2':'Name','FIELDS_TO_COPY':[],'METHOD':1,'DISCARD_NONMATCHING':False,'PREFIX':'','OUTPUT':path_shapefiles+'Results_Scenario_'+str(scenario)+'.shp'})
map_results_scenario = QgsVectorLayer(path_shapefiles + 'Results_Scenario_'+str(scenario)+'.shp', "map_results_scenario", "ogr")
QgsProject.instance().addMapLayer(map_results_scenario)

# Create shapefiles for each of the SUDS
# Green Roofs
processing.run("native:extractbyattribute", {'INPUT':map_results_scenario,'FIELD':'SUDS','OPERATOR':0,'VALUE':'Green_Roof','OUTPUT':path_shapefiles+'green_roofs.shp'})
green_roofs = QgsVectorLayer(path_shapefiles + 'green_roofs.shp', "green_roofs", "ogr")
QgsProject.instance().addMapLayer(green_roofs)

# Infiltration_Trenches
processing.run("native:extractbyattribute", {'INPUT':map_results_scenario,'FIELD':'SUDS','OPERATOR':0,'VALUE':'Infiltration_Trenches','OUTPUT':path_shapefiles+'Infiltration_Trenches.shp'})
Infiltration_Trenches = QgsVectorLayer(path_shapefiles + 'Infiltration_Trenches.shp', "Infiltration_Trenches", "ogr")
QgsProject.instance().addMapLayer(Infiltration_Trenches)

# Permeable_Pavement
processing.run("native:extractbyattribute", {'INPUT':map_results_scenario,'FIELD':'SUDS','OPERATOR':0,'VALUE':'Permeable_Pavement','OUTPUT':path_shapefiles+'Permeable_Pavement.shp'})
Permeable_Pavement = QgsVectorLayer(path_shapefiles + 'Permeable_Pavement.shp', "Permeable_Pavement", "ogr")
QgsProject.instance().addMapLayer(Permeable_Pavement)

# Rain_Garden
processing.run("native:extractbyattribute", {'INPUT':map_results_scenario,'FIELD':'SUDS','OPERATOR':0,'VALUE':'Rain_Garden','OUTPUT':path_shapefiles+'Rain_Garden.shp'})
Rain_Garden = QgsVectorLayer(path_shapefiles + 'Rain_Garden.shp', "Rain_Garden", "ogr")
QgsProject.instance().addMapLayer(Rain_Garden)