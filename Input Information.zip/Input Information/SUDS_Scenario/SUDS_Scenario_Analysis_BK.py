#!/usr/bin/env python
# coding: utf-8

# In[1]:



##################################################################################################
# Imports neccesary libraries and tools
##################################################################################################

import subprocess
import numpy as np
import re
import pandas as pd
##################################################################################################
# Runs the model and generates the .OUT and .RPT files
##################################################################################################

#Manually define the name of the .inp file
name_model = 'ms5_SUDS'

#Run the model
cm= 'swmm5.exe ' + name_model + '.inp ' + name_model + '.rpt ' + name_model + '.out'
print (cm)
subprocess.call(cm)


# In[2]:



##################################################################################################
# Read results to extract information about node flooding and surcharge
##################################################################################################

#read the RPT file of SWMM

name_rpt= name_model + '.rpt'

f= open(name_rpt, 'r')

#read each line and storages it as a list of strings

lines= f.readlines()

 

#find the section for NODE FLOODING

idx_ini= lines.index('  Node Flooding Summary\n')

idx_end= lines.index('  Outfall Loading Summary\n')

 

#if no flooding happend then a message is displayed, if flood happend then a numpy array with the ID of node, duration in hours

#and volume in 10^6 L is created. A csv file with this results is also created, but the volume is changed to m^3

if idx_ini == -1:

    print('NO NODE FLOODING')

else:

    idx_st=idx_ini+10

    idx= lines[idx_st:idx_end].index('  \n')

    node_flood= lines[idx_st:idx_st+idx]

    flood_file=open('Node_flooding_' + name_model + '.csv', 'w')

    flood_file.write('Node_ID, Duration[h], Volume[m^3]\n')

    res_flood=np.zeros((len(node_flood),3))
    res_flood_str = ["" for i in range(len(node_flood))]

    for i in range(0, len(node_flood)):

        a=node_flood[i].split()

        res_flood_str[i]=a[0]
        #res_flood[i,0]=i

        res_flood[i,1]=a[1]

        res_flood[i,2]=a[5]
        
        #flood_file.write(str(int(res_flood[i,0])) + ',' + str(res_flood[i,1]) + ',' + str(res_flood[i,2]*1000) +'\n')
        flood_file.write(res_flood_str[i] + ',' + str(res_flood[i,1]) + ',' + str(res_flood[i,2]*1000) +'\n')


    flood_file.close()




