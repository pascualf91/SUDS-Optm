function output = SUDS_Selection_Fun(in)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Define paths %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
root = 'C:\Users\pascu\Dropbox\Pascual\UPV PhD\6. Pasantia TUD\Kilma Konform\Own Developed';

model_name = 'STRASSBERG_10T_120D';

base_scenario_info = strcat(root, '\Input Information\Base Scenario');

SUDS_info = strcat(root, '\Input Information\SUDS_Scenario');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Define SUDS Design Parameters %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Loads the Excel spreatsheet with SUDS Design Parameters
cd (SUDS_info)
SUDS_param=importdata("/Design Parameters SUDS.xlsx");

%Load the .inp model as an array
d=mepa_read_inp(strcat(model_name, '_BASE_SUDS.inp'));

%Asigna parámetros a Celda de Bioretención (BC)
d.LID_CONTROLS(2,3)= cellstr(num2str(SUDS_param.data(1,1)));
d.LID_CONTROLS(2,4)= cellstr(num2str(SUDS_param.data(2,1)));
d.LID_CONTROLS(3,3)= cellstr(num2str(SUDS_param.data(5,1)));
d.LID_CONTROLS(5,4)= cellstr(num2str(SUDS_param.data(10,1)));

%Asigna parámetros a Techo Verde (GR)
d.LID_CONTROLS(7,3)= cellstr(num2str(SUDS_param.data(1,2)));
d.LID_CONTROLS(7,4)= cellstr(num2str(SUDS_param.data(2,2)));
d.LID_CONTROLS(8,3)= cellstr(num2str(SUDS_param.data(5,2)));
d.LID_CONTROLS(9,3)= cellstr(num2str(SUDS_param.data(14,2)));

%Asigna parámetros a jardín de Lluvia (RG)
d.LID_CONTROLS(11,3)= cellstr(num2str(SUDS_param.data(1,3)));
d.LID_CONTROLS(11,4)= cellstr(num2str(SUDS_param.data(2,3)));
d.LID_CONTROLS(12,3)= cellstr(num2str(SUDS_param.data(5,3)));

%Asigna parámetros a Trinchera de Infiltración (IT)
d.LID_CONTROLS(15,3)= cellstr(num2str(SUDS_param.data(1,4)));
d.LID_CONTROLS(15,4)= cellstr(num2str(SUDS_param.data(2,4)));
d.LID_CONTROLS(16,3)= cellstr(num2str(SUDS_param.data(7,4)));
d.LID_CONTROLS(17,5)= cellstr(num2str(SUDS_param.data(10,4)));

%Asigna parámetros a Pavimentos Permeables (PP)
d.LID_CONTROLS(19,3)= cellstr(num2str(SUDS_param.data(1,5)));
d.LID_CONTROLS(19,4)= cellstr(num2str(SUDS_param.data(2,5)));
d.LID_CONTROLS(21,3)= cellstr(num2str(SUDS_param.data(5,5)));
d.LID_CONTROLS(22,3)= cellstr(num2str(SUDS_param.data(7,5)));
d.LID_CONTROLS(23,5)= cellstr(num2str(SUDS_param.data(10,5)));
d.LID_CONTROLS(20,3)= cellstr(num2str(SUDS_param.data(12,5)));

%Asigna parámetros a Barril de Lluvia (RB)
d.LID_CONTROLS(25,3)= cellstr(num2str(SUDS_param.data(7,6)));
d.LID_CONTROLS(26,5)= cellstr(num2str(SUDS_param.data(10,6)));

%Asigna parámetros a Swale Vegetado (VS)
d.LID_CONTROLS(28,3)= cellstr(num2str(SUDS_param.data(1,7)));
d.LID_CONTROLS(28,4)= cellstr(num2str(SUDS_param.data(2,7)));
d.LID_CONTROLS(28,7)= cellstr(num2str(SUDS_param.data(3,7)));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Define SUDS Design Distribution %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Define the number of subcatchments, as it will define the number of input
%variables to the optimization problem
num_subcat = length(d.SUBCATCHMENTS);

build_subcat = strncmpi(d.SUBCATCHMENTS(:,1),'BU',2);
streets_subcat = strncmpi(d.SUBCATCHMENTS(:,1),'ST',2);

num_buildings = sum(build_subcat);
num_streets = sum(streets_subcat);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%% BUILDINGS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Define the distribution of SUDS for the Buildings Subcatchments

%Define a list of the posible SUDS to be assigned in the streets
%order={'BC', 'GR', 'RG', 'IT', 'PP', 'RB', 'VS'};
typo_bu = {'GR', 'RG'};
num_tip_bu = length(typo_bu);

%Define an input equal to the percentage of area in each subcatchment
%assigned to each typology. Initialy set as 1%
p_bu = ones(num_buildings,num_tip_bu);

%Calculates de area in m2 of each SUDS to be assigned
for i = 1:num_buildings
    for j=1:num_tip_bu
        a_bu(i,j) = ((p_bu(i,j)/100) * str2double(string(d.SUBCATCHMENTS(i,4))))*10000;
    end
end


%Assigns the LID_USAGE features
num_variables_bu = num_tip_bu*num_buildings;
cont_subc=1;

for i =1:num_tip_bu
    con_nom_sub=1;
    for j= 1:num_buildings
        d.LID_USAGE(cont_subc,1) = cellstr(strcat('BU_', num2str(con_nom_sub-1)));

        d.LID_USAGE(cont_subc, 2) = typo_bu(i);

        d.LID_USAGE(cont_subc, 3) = cellstr(num2str(1));
        
        d.LID_USAGE(cont_subc, 4) = cellstr(num2str(a_bu(j,i)));

        d.LID_USAGE(cont_subc, 5) = cellstr(num2str(str2double(string(d.SUBCATCHMENTS(j,6)))));

        d.LID_USAGE(cont_subc, 6) = cellstr(num2str(0));

        d.LID_USAGE(cont_subc, 7) = cellstr(num2str(100/num_tip_bu));

        d.LID_USAGE(cont_subc, 8) = cellstr(num2str(0));

        cont_subc = cont_subc+1;
        con_nom_sub = con_nom_sub+1;
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%% STREETS %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Define the distribution of SUDS for the Street Subcatchments

%Define a list of the posible SUDS to be assigned in the streets
%order={'BC', 'GR', 'RG', 'IT', 'PP', 'RB', 'VS'};
typo_st = {'PP'};
num_tip_st = length(typo_st);

%Define an input equal to the percentage of area in each subcatchment
%assigned to PP. Initialy set as 1%
p_pp = ones(num_streets,num_tip_st);

%Calculates de area in m2 of each PP to be assigned
for i = 1:num_streets
    for j=1:num_tip_st
        a_pp(i,j) = ((p_pp(i,j)/100) * str2double(string(d.SUBCATCHMENTS(i+num_buildings,4))))*10000;
    end
end


%Assigns the LID_USAGE features
num_variables_st = num_tip_st*num_streets;
cont_subc=num_variables_bu+1;

for i =1:num_tip_st
    con_nom_sub=1;
    for j= 1:num_streets
        d.LID_USAGE(cont_subc,1) = cellstr(strcat('ST_', num2str(con_nom_sub-1)));

        d.LID_USAGE(cont_subc, 2) = typo_st(i);

        d.LID_USAGE(cont_subc, 3) = cellstr(num2str(1));
        
        d.LID_USAGE(cont_subc, 4) = cellstr(num2str(a_pp(j,i)));

        d.LID_USAGE(cont_subc, 5) = cellstr(num2str(str2double(string(d.SUBCATCHMENTS(j+num_buildings,6)))));

        d.LID_USAGE(cont_subc, 6) = cellstr(num2str(0));

        d.LID_USAGE(cont_subc, 7) = cellstr(num2str(100/num_tip_st));

        d.LID_USAGE(cont_subc, 8) = cellstr(num2str(0));

        cont_subc = cont_subc+1;
        con_nom_sub = con_nom_sub+1;
    end
end

%Prints the .inp file with the SUDS distribution assigned
cd(SUDS_info)
model_SUDS_name =strcat(model_name, '_SUDS.inp');
mepa_write_inp(model_SUDS_name, d);
cd(root)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Extract Results information %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Calls the Python Script to run and extract results for SUDS Scenario
cd(SUDS_info)
system ('python SUDS_Scenario_Analysis.py');
csv_file_name_SUDS = strcat('Node_flooding_', model_name, '_SUDS.csv');
node_flooding_SUDS = importdata(csv_file_name_SUDS);
total_flooded_volume_SUDS = sum(node_flooding_SUDS.data(:,3));
cd(root)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Calculates Cost and Define Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
cd(SUDS_info)
unitary_costs = importdata("Unitary Costs.xlsx")
cd(root)

%Auxiliar variables
bc=0;
gr=0;
rg=0;
it=0;
pp=0;
rb=0;
vs=0;

%Identify and summ up the areas used from each typology
size_suds=size(d.LID_USAGE);
for i= 1:size_suds(1)
    if strcmpi(d.LID_USAGE(i,2), 'BC') == 1
        bc=bc + str2num(cell2mat(d.LID_USAGE(i,4)));
    elseif strcmpi(d.LID_USAGE(i,2), 'GR') == 1
        gr=gr + str2num(cell2mat(d.LID_USAGE(i,4)));
    elseif strcmpi(d.LID_USAGE(i,2), 'RG') == 1
        rg=rg + str2num(cell2mat(d.LID_USAGE(i,4)));
    %Unitary cost in m3. Multiply by the width of the structure
    elseif strcmpi(d.LID_USAGE(i,2), 'IT') == 1
        it=it + str2num(cell2mat(d.LID_USAGE(i,4))) * str2num(cell2mat(d.LID_USAGE(i,5)));
    elseif strcmpi(d.LID_USAGE(i,2), 'PP') == 1
        pp=pp + str2num(cell2mat(d.LID_USAGE(i,4)));
    elseif strcmpi(d.LID_USAGE(i,2), 'RB') == 1
        %Unitary cost in m3. Multiply by the width of the structure
        rb=rb + str2num(cell2mat(d.LID_USAGE(i,4))) * str2num(cell2mat(d.LID_USAGE(i,5)));
    elseif strcmpi(d.LID_USAGE(i,2), 'VS') == 1
        vs=vs + str2num(cell2mat(d.LID_USAGE(i,4)));
    else
    end
end

Areas = [bc; gr; rg; it; pp; rb; vs];

%Capital cost
capital_cost=Areas .* unitary_costs.data(:,1);
%Calcula el costo de mantenimiento y operación
costo_manten_anual= capital_cost .* (unitary_costs.data(:,2)/100);
%calcula el Valor Presente Neto para 30 años de vida útil con 3% de tasa de
%descuento
costo_manten_proy = pvfix(0.03, 30, costo_manten_anual);
%Suma los costos totales
costo_total = sum(capital_cost) + sum(costo_manten_proy);

%Calcula el Costo óptimo como millones de euros
costo_optim = costo_total/1000000;
output = [total_flooded_volume_SUDS costo_optim]

end