import pandas as pd
import numpy as np
import scipy 

#Path where initial (user defined) and final shapefiles are located
path_shapefiles= 'C:/Users/pascu/Dropbox/Pascual/UPV PhD/6. Pasantia TUD/Swmm models dresden/Flooding Model/Shapefiles/'

#Path where temporary layers are stored
path_folder= 'C:/Users/pascu/Dropbox/Pascual/UPV PhD/6. Pasantia TUD/Swmm models dresden/Flooding Model/Shapefiles/temp/'

#path where flood flides are located
path_flood= 'C:/Users/pascu/Dropbox/Pascual/UPV PhD/6. Pasantia TUD/Swmm models dresden/Flooding Model/SWMM model/'

#-------------------------------------------------------------------------------------------------------------------------------------------------
#1.1 LOAD basic shapefiles
#-------------------------------------------------------------------------------------------------------------------------------------------------

#load DEM of study area
dem_raster = QgsRasterLayer(path_shapefiles + 'DEM_MS5.tif', "DEM")
QgsProject.instance().addMapLayer(dem_raster)

#load network outlet
outlet_network= QgsVectorLayer(path_shapefiles + 'SWMM_outfalls.shp', "outlet_network", "ogr")
QgsProject.instance().addMapLayer(outlet_network)

#loads base sewer node layer to QGIS
base_sewer_nodes= QgsVectorLayer(path_shapefiles + 'SWMM_junctions.shp', "sewer_nodes", "ogr")
QgsProject.instance().addMapLayer(base_sewer_nodes)

#load connected buildings
connected_buildings= QgsVectorLayer(path_shapefiles + 'connected_buildings.shp', "connected_buildings", "ogr")
QgsProject.instance().addMapLayer(connected_buildings)

#loads base sewer layer to QGIS
base_sewer_DESIGNED= QgsVectorLayer(path_shapefiles + 'SWMM_conduits.shp', "sewer_network", "ogr")
QgsProject.instance().addMapLayer(base_sewer_DESIGNED)

#-------------------------------------------------------------------------------------------------------------
#1.1. inout data
#---------------------------------------------------------------------------------------------------------
#name SWMM model results for node flooding
name_swmm= 'Node_flooding_10T_30D.csv'

#convert dem to ASCII
#processing.run("gdal:translate", {'INPUT':dem_raster,'TARGET_CRS':None,'NODATA':-9999,'COPY_SUBDATASETS':False,'OPTIONS':'','EXTRA':'','DATA_TYPE':0,'OUTPUT':path_folder + 'dem_10.asc'})

#name of the DEM, it has to be in ASCII format
name_dem= path_shapefiles + 'dem_10.asc'
dem= np.loadtxt(name_dem, skiprows=6)
dem=np.around(dem,3)

#name of flood file
df_flood=pd.read_csv( path_flood + name_swmm)
np_flood= df_flood.to_numpy()
np_flood_id=np_flood[:,0].astype(int)
np_flood_vols= np_flood[:,2].astype(float)

#-------------------------------------------------------------------------------------------------------------
#1.1. Pre-processing 
#---------------------------------------------------------------------------------------------------------

#read the DEM file 
f= open(name_dem, 'r')
#read each line and storages information of the DEM as a list of strings
lines= f.readlines()
dem_info= lines[0:6]
f.close()

#Caculate the area of each cell 
a= dem_info[4].split()
cell_size= float(a[1])
Acell= int(cell_size**2)

#Minimum water level--> threshold or border condition to stop iteration
minH=0.05

#Height threshold to ensure flow
h_thr=0.1

#change NO DATA values for 9999 to ensure water does not flow outside raster
a= dem_info[5].split()
no_data= float(a[1])
pos=np.argwhere(dem==no_data)
if len(pos)>0:
    dims=pos.shape
    for i in range(0,dims[0]):
        temp=pos[i,]
        dem[temp[0], temp[1]]=9999
        
#cretae raster with IDs for each grid cell of the DEM
d=dem.shape
id_matrix=np.zeros([d[0],d[1]])
it=0
for i in range(0,d[0]):
    for j in range(0,d[1]):
        it=it+1
        id_matrix[i,j]=int(it)
        
np.savetxt(path_folder + 'dem_ids.txt', id_matrix, fmt ='%.0f')
f1=open(path_folder + 'dem_ids.txt', 'r')
lines_2=f1.readlines()
f1.close()
c=dem_info + lines_2
with open(path_folder + 'dem_ids.asc', 'w') as f2:
    for item in c:
        f2.write("%s\n" % item)
f2.close()

#convert raster to points 
processing.run("native:pixelstopoints", {'INPUT_RASTER':path_folder + 'dem_ids.asc','RASTER_BAND':1,'FIELD_NAME':'dem_ids','OUTPUT':path_folder + 'dem_ids_point.shp'})

#load DEM_ids
dem_ids = QgsVectorLayer(path_folder + 'dem_ids_point.shp', "DEM_ids")
QgsProject.instance().addMapLayer(dem_ids)

#join sewer nodes with dem ids to determine location 
processing.run("native:joinbynearest", {'INPUT': base_sewer_nodes,'INPUT_2':path_folder + 'dem_ids_point.shp','FIELDS_TO_COPY':[],'DISCARD_NONMATCHING':False,'PREFIX':'','NEIGHBORS':1,'MAX_DISTANCE':None,'OUTPUT':path_folder + 'join_nodes_dem.shp'})
processing.run("qgis:deletecolumn", {'INPUT':path_folder +'join_nodes_dem.shp','COLUMN':['x','y','INVERT_ELV','n','distance','feature_x','feature_y','nearest_x','nearest_y'],'OUTPUT':path_folder + 'join_nodes_dem_2.shp'})
#save to CSV for further processing
processing.run("native:savefeatures", {'INPUT':path_folder + 'join_nodes_dem_2.shp','OUTPUT':path_folder + 'join_nodes_dem.csv','LAYER_NAME':'','DATASOURCE_OPTIONS':'','LAYER_OPTIONS':''})

#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#FLOOD PROPAGATION
#--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

#Function to determnine nearby neighbors

def near_neighbors(arr, prows, pcol):
    from scipy import signal
    arr2=np.array([[1,1,1],[1,0,1],[1,1,1]])
    D=np.zeros((arr.shape[0], arr.shape[1]))
    D[prows,pcol]=1
    a=scipy.signal.convolve2d(D,arr2, mode='same')
    pos=np.where(a>0)
    neighbors=arr[pos]
    return(neighbors)



df_join=pd.read_csv(path_folder + 'join_nodes_dem.csv')
np_join= df_join.to_numpy()
np_join=np_join.astype(int)

id_matrix=id_matrix.astype(int)
flood_raster=np.zeros([d[0],d[1]])# extension and depth



for i in range(0, len(np_flood_id)):
    posx= np.where(np_flood_id[i]==np_join[:,0])[0][0]# find the flooding node in the list of sewer nodes

    px=np.where(np_join[posx,6]==id_matrix)[0][0]#find the row of near DEM grid for the flooding node
    py=np.where(np_join[posx,6]==id_matrix)[1][0]#find the column of near DEM grid for the flooding node

    vol= np_flood_vols[i]

    M=np.zeros([d[0],d[1]])
    temp_M=M 
    M[px,py]=1
    neigh= near_neighbors(dem,px,py)
    next_neigh=[]
    if (neigh[0]- dem[px,py])<h_thr:
        M[px-1,py-1]=1
        next_neigh.append([px-1,py-1])#upper left corner

    if (neigh[1]-dem[px,py])<h_thr:
        M[px-1,py]=1
        next_neigh.append([px-1,py])#up

    if (neigh[2]- dem[px,py])<h_thr:
        M[px-1,py+1]=1
        next_neigh.append([px-1,py+1])#upper right corner

    if (neigh[3]- dem[px,py])<h_thr:
        M[px,py-1]=1
        next_neigh.append([px,py-1])# left 

    if (neigh[4]- dem[px,py])<h_thr:
        M[px,py+1]=1
        next_neigh.append([px,py+1])#right

    if (neigh[5]- dem[px,py])<h_thr:
        M[px+1,py-1]=1
        next_neigh.append([px+1,py-1])#lower left corner

    if (neigh[6]- dem[px,py])<h_thr:
        M[px+1,py]=1
        next_neigh.append([px+1,py])#down

    if (neigh[7]- dem[px,py])<h_thr:
        M[px+1,py+1]=1
        next_neigh.append([px+1,py+1])#lower right corner

    it_vol=vol/len(next_neigh)#divide all volume in all the flooded cells for that iteration
    outH=it_vol/Acell #calculate threshold condition
    #flood_raster=flood_raster+M #update flood extension   
    temp_M= temp_M+M #update for next iteration

    #Further iterations
    if len(next_neigh)>0:
        ctr=0
        while outH>minH:
            if len(next_neigh)>0:
                temp_vol=it_vol
                npos= next_neigh
                next_neigh=[]
                for i in range(0, len(npos)):
                    M=np.zeros([d[0],d[1]])
                    px= npos[i][0]
                    py= npos[i][1]
                    M[px,py]=1
                    neigh= near_neighbors(dem,px,py)
                    next_neigh=[]
                    if (neigh[0]- dem[px,py])<h_thr:
                        M[px-1,py-1]=1
                        next_neigh.append([px-1,py-1])#upper left corner

                    if (neigh[1]- dem[px,py])<h_thr:
                        M[px-1,py]=1
                        next_neigh.append([px-1,py])#up

                    if (neigh[2]- dem[px,py])<h_thr:
                        M[px-1,py+1]=1
                        next_neigh.append([px-1,py+1])#upper right corner

                    if (neigh[3]- dem[px,py])<h_thr:
                        M[px,py-1]=1
                        next_neigh.append([px,py-1])# left 

                    if (neigh[4]- dem[px,py])<h_thr:
                        M[px,py+1]=1
                        next_neigh.append([px,py+1])#right

                    if (neigh[5]- dem[px,py])<h_thr:
                        M[px+1,py-1]=1
                        next_neigh.append([px+1,py-1])#lower left corner

                    if (neigh[6]- dem[px,py])<h_thr:
                        M[px+1,py]=1
                        next_neigh.append([px+1,py])#down

                    if (neigh[7]- dem[px,py])<h_thr:
                        M[px+1,py+1]=1
                        next_neigh.append([px+1,py+1])#lower right corner
                    #flood_raster=flood_raster+M #update flood extension   
                    temp_M= temp_M+M #update for next iteration
            else:
                break
            ctr=ctr+1
            if ctr>100:
                break
            c=np.array(next_neigh)
            next_neigh=list(np.unique(c, axis=0))
            it_vol=vol/len(next_neigh)#divide all volume in all the flooded cells for that iteration
            outH=it_vol/Acell #calculate threshold condition

        flood_area= Acell*len(np.where(temp_M>0)[0])
        flood_depth= vol/flood_area
    else:
        flood_area= Acell*len(np.where(temp_M>0)[0])
        flood_depth= vol/flood_area 

    temp_M[np.where(temp_M >0)]=flood_depth
    flood_raster=flood_raster+temp_M
    
flood_raster[np.where(flood_raster==0)]= no_data

np.savetxt(path_folder + 'temp_flood_extent.txt', flood_raster, fmt ='%.4f')
f3=open(path_folder + 'temp_flood_extent.txt', 'r')
lines_3=f3.readlines()
f3.close()
c=dem_info + lines_3
with open(path_shapefiles + name_swmm + '_flood_raster.asc', 'w') as f4:
    for item in c:
        f4.write("%s\n" % item)
f4.close()

#load flood raster
flood_raster = QgsRasterLayer(path_shapefiles + name_swmm + '_flood_raster.asc', "Flood_areas")
QgsProject.instance().addMapLayer(flood_raster)

#remove unnecesary data
QgsProject.instance().removeMapLayer(dem_raster)
QgsProject.instance().removeMapLayer(dem_ids)


